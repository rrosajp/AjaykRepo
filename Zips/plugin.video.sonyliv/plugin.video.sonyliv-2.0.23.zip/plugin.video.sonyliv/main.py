import sys

from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui
from urllib.parse import urlencode, quote, parse_qsl
import six
import re
import requests
import urllib
from urllib.request import urlopen, Request
import time
import math
from datetime import datetime
from json import dumps
import uuid
import web_pdb

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon()
_addonname = _addon.getAddonInfo("name")
_version = _addon.getAddonInfo("version")
_addonID = _addon.getAddonInfo("id")
_icon = _addon.getAddonInfo("icon")
_fanart = _addon.getAddonInfo("fanart")
_settings = _addon.getSetting

window = xbmcgui.Window(10000)


# window.setProperty("LoadPage", 'True')

cache = StorageServer.StorageServer("sonyliv", _settings("timeout"))

headers = {
    "Content-Type": "application/json",
    "App_version": "3.5.8",
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.9",
    "Origin": "https://www.sonyliv.com",
    "Referer": "https://www.sonyliv.com/",
    "X-Via-Device": "true"
}

try:
    platform = re.findall(r"\(([^)]+)", xbmc.getUserAgent())[0]
except:
    platform = "Linux; Android 7.1.1"


USER_AGENT = "Mozilla/5.0 ({}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43".format(
    platform
)
sessionid="%s-%d" % (uuid.uuid4().hex, time.time() * 1000)
headers["Session_id"] = sessionid
headers["User-Agent"] = USER_AGENT
#headers["Session_id"] = uuid.uuid4().hex + "-" + USER_AGENT


#headers["Cookie"] = '_abck=B57B0B09CC74B0038FC0532378C47C97~0~YAAQ3/zUF3kaL1WQAQAAbsXdhgyyqRiUXXsQATK/OrymuyKCDazDuHh1I/yjIX2rTpxOdabrhThGWNZ3pOnA2xuVLoOtVrVt6uFKe+1t749hv80E1hnRRsKz1dqts8sJDSmK5TUV6mp2GzqSTn8xkwnXrn+WGXYdEN4x4oQMPRBicJjP9+l6NH7HaH4dCLvvTM7apF9ZpJNZ32CDWQPHcRr+5+CyeSa4rxiUNHj0HpvlnQ8ArfGLsGtli4XYdPBy3/JByHzESx8RpDYYobxhNTwiKYown1l0+goT9IfkhHnVXe7yMq/YKw6GsaYgOs3EoZsSMvhyE++a5sZM2dAdm5FUiQCC2pwxZYrWQXVyf0tU8Pz3tpX6lq58c/gjPRrRkshsJ1ibO5tKv40bl7vxRb+G/YZf9xPxYG5Yv2HQYmoNKQBNEVrVYRlyQth5zyz5fcuR5FM=~-1~-1~-1;;'
headers["Cookie"] = '_abck=38C3B742CF1F744421D0E563F08A690B~0~YAAQ5RzFF9AvWAefAQAAKzgiIhAJdvIsDIFf9b/yXXE6qjNgYf02WfxdbcS0PRUJjvmDS8uZlbBRb+2WEpBPsADHS8QlrcwYO9TNgL7ZFUvTGHN0x+9f/tOlhwWOxZDlZowwGvnSxKm1R+m9uhvXl6pMBigmPuTtLnDMoY6A0tuWp/OhGLWhGNL2PzlG9WEUv8+zvlT7gUs19JtCTS3rOgHhtSixNdAp3flxSgXjiWYJTopYRMFdEb2qoVD4F92/zQbxf7tWN5dl23+EP8CZHr9ZQD4TetrTj7UTtxUUTSxled04/8wNmCvJNSBy8cKieiFgp2msz4U3/SVYakb/5uIP8RZ7G+LEE8WJ1TTZvAdZE3zfc7ZXxcWx+FQ59gbaks6Z6C5J3VBQNiNGB3Muy4zJBcu9MUVmiY+EYrT1FSpIPzu+Im2eqtt6DIYhd4+KI34lBJCV5z9NnTr1JbPpRAk3FiCWHNVKHZh2SU13J20KTx+0llTxJVFh2mVMduFlgGzesDSzgrK2sgWd/C5z+0/DNXEjsBSkM7rbVNG+ggePJ2/dYCvL9tqIZDMLJQ3FnlrqNwmpyCCGHvWIvuVDqCS79GJjIKe9J9frC8lCVU1sMGCRUFCVZVqyGQxAAuN7aGxXXxqWjLeMehR33ObCWDiMgLPeA3YCiM0xorDMMCK32cYAqWZ34n/Ty3RCFRuk+KofdXmUFeBzhk05YnYXadhf+Nem4SfbkBRoQ26MnZ0DzAbsGJrBChGGA01e4LRbyH2O9gKcTjsrVqiHtH5d1N34ZFYwe2zGBqKsMxDma/Zl6Z6Bdlser55tBKUXB09UtdQ0/6M6eWW0~-1~-1~-1~AAQAAAAE%2f%2f%2f%2f%2fxaJo9%2fHAr8XfTDsV9v1VH88lv2QXEQE+xuCI4IPbL+Od5ocyXHeL0rNOn2E90oTJYvsvszjQCFIsIzhdsc6rHoK3fpYlHHvIpWQ~-1;'
headers["Cookie"] = headers["Cookie"] + '; sessionId=' + quote(sessionid, safe='/(),') + ';'

"""
r = requests.get('https://www.sonyliv.com/', headers=headers)
cookie = r.cookies.get_dict()
c1 = '_abck=' + cookie.get("_abck") 

headers["Cookie"] = c1 + '; sessionId=' + quote(headers["Session_id"], safe='/(),') + ';'
"""
xbmc.log(headers["Cookie"], xbmc.LOGINFO)

def get_token():
    url = "https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/ALL/GETTOKEN"
    data = requests.get(url, headers=headers).json()
    return data["resultObj"]


if "security_token" not in headers:
    headers["Security_token"] = get_token()


"""
def get_Device_id():
    e = int(time.time() * 1000)
    t = list('xxxyxxxxxxxx4xxxyxxxxxxxxxxxxxxx')
    for i, c in enumerate(t):
        n = int((e + 16 * random.random()) % 16) | 0
        e = math.floor(e / 16)
        if c == 'x':
            t[i] = str(n)
            opt=1
        elif c == 'y':
            t[i] = '{:x}'.format(3 & n | 8)
            opt=2
        xbmc.log('%s - %s - %s' %(i,opt,t[i]))
    return ''.join(t) + '-' + str(int(time.time() * 1000))
"""

headers["Device_id"] = "9c7631d21edd4a65a92b2b641c8a13a2-1634808345996"


def get_ULD():
    url = "https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/ALL/USER/ULD"
    r = requests.get(url, headers=headers)
    data = r.json()
    #cookie = r.cookies.get_dict()
    #headers["Cookie"] = '_abck=' + cookie.get("_abck") + '; sessionId=' + quote(headers["Session_id"], safe='/(),') + ';'
    if data:
        ULD = [
            ("state", data["resultObj"].get("state_code")),
            ("channelPartnerID", data["resultObj"].get("channelPartnerID")),
        ]
    return ULD


ULD = get_ULD()
state = ULD[0][1]
channelPartnerID = ULD[1][1]


def GETPROFILE():
    url = "https://apiv2.sonyliv.com/AGL/2.9/A/ENG/WEB/IN/%s/GETPROFILE?channelPartnerID=%s" % (state, channelPartnerID)
    data = requests.get(url, headers=headers).json()
    if data:
        contactID = data['resultObj']['contactMessage'][0].get('contactID')
    return contactID


def clear_cache():
    """
    Clear the cache database.
    """

    msg = "Cached Data has been cleared"
    cache.table_name = "sonyliv"
    cache.cacheDelete("%get%")
    _addon.setSetting("Authorization", "")
    xbmc.executebuiltin("Notification(%s, %s, %d, %s)" %
                        (_addonname, msg, 3000, _icon))


def login():
    mobile = _settings("mobile")
    if mobile:
        url = "https://apiv2.sonyliv.com/AGL/1.6/A/ENG/WEB/IN/%s/CREATEOTP-V2" % (
            state)
        Pattern = re.compile("[6-9][0-9]{9}")
        if Pattern.match(mobile):
            body = {
                "channelPartnerID": channelPartnerID,
                "country": "IN",
                "isMobileMandatory": True,
                "loginType": "REGISTERORSIGNIN",
                "mobileNumber": mobile,
                "otpSize": "4",
                "timestamp": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%MZ")
            }
            
            # web_pdb.set_trace()
            body = dumps(body)
            jd = requests.post(url, headers=headers, data=body, timeout=5).json()
            xbmc.log(dumps(jd))
            if jd.get("resultCode") == "KO":
                xbmc.executebuiltin(
                    "Notification(%s, %s, %d, %s)"
                    % (_addonname, "Error Sending OTP", 3000, _icon)
                )
            else:
                OTP = xbmcgui.Dialog().numeric(0, "Enter OTP")

                url = (
                    "https://apiv2.sonyliv.com/AGL/2.0/A/ENG/WEB/IN/%s/CONFIRMOTP-V2"
                    % (state)
                )
                body = {
                    "address": {"state": state},
                    "channelPartnerID": "MSMIND",
                    "country": "IN",
                    "ageConfirmation": True,
                    "dmaId": "IN",
                    "isMobileMandatory": True,
                    "deviceDetails": {
                        "appClientId": "1212475532.1575468358",
                        "deviceName": "NA",
                        "deviceType": "webClient",
                        "gaUserId": "GA1.2.1212475532.1575468358",
                        "modelNo": "Chrome Browser",
                        "serialNo": headers.get("Device_id"),
                    },
                    "mobileNumber": mobile,
                    "otp": OTP,
                    "timestamp": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%MZ"),
                }
                body = dumps(body)
                jd = requests.post(url, headers=headers, data=body).json()
                xbmc.log(dumps(jd))
                if jd.get("resultCode") == "OK":
                    headers.update(
                        {"authorization": jd["resultObj"]["accessToken"]})
                    _addon.setSetting(
                        "Authorization", jd["resultObj"]["accessToken"])
                    _addon.setSetting(
                        "isSubscribed", str(jd["resultObj"]["isSubscribed"]))
                    xbmc.executebuiltin(
                        "Notification(%s, %s, %d, %s)"
                        % (_addonname, "Login Successful", 3000, _icon)
                    )
                else:
                    xbmc.executebuiltin(
                        "Notification(%s, %s, %d, %s)"
                        % (_addonname, "Invalid/Expired OTP", 3000, _icon)
                    )
        else:
            xbmc.executebuiltin(
                "Notification(%s, %s, %d, %s)"
                % (_addonname, "Invalid Mobile Number", 3000, _icon)
            )
    else:
        xbmc.executebuiltin(
            "Notification(%s, %s, %d, %s)"
            % (_addonname, "Please Enter Mobile Number in Settings", 3000, _icon)
    )
    return

# web_pdb.set_trace()
if _settings("Authorization"):
    headers.update({"authorization": _settings("Authorization")})
    # headers.update({"authorization": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxODA3MTcxMTM4NjI3NzI4MjYiLCJ0b2tlbiI6Ilh2QmgtYldOMy1QWXZ2LVlVOGUtQlNtMS1zTEg3LU9iIiwiZXhwaXJhdGlvbk1vbWVudCI6IjIwMjMtMDktMjFUMTA6NTM6MDUuOTY1WiIsImlzUHJvZmlsZUNvbXBsZXRlIjp0cnVlLCJzZXNzaW9uQ3JlYXRpb25UaW1lIjoiMjAyMi0wOS0yMVQxMDo1MzowNS45NjZaIiwiY2hhbm5lbFBhcnRuZXJJRCI6Ik1TTUlORCIsImZpcnN0TmFtZSI6Ik1lZW5ha3NoaXByYWthc2giLCJtb2JpbGVOdW1iZXIiOiI5ODIwNDcwNjkwIiwiZGF0ZU9mQmlydGgiOi02NzgyNDAwMDAwMCwiZ2VuZGVyIjoiRmVtYWxlIiwicHJvZmlsZVBpYyI6IiIsInNvY2lhbFByb2ZpbGVQaWMiOiJodHRwczovL3BsYXRmb3JtLWxvb2thc2lkZS5mYnNieC5jb20vcGxhdGZvcm0vcHJvZmlsZXBpYy8_YXNpZD0xMDU2NzI1Nzc3ODEwMjcwJmhlaWdodD0yMDAmd2lkdGg9MjAwJmV4dD0xNTY4OTkzOTAzJmhhc2g9QWVSUjBqNk1LcFlVaF90SiIsInNvY2lhbExvZ2luSUQiOiJHVV8xMTY5NDI1OTQxMTAwMzU4MjQzMDUiLCJzb2NpYWxMb2dpblR5cGUiOiJHb29nbGUiLCJpc0VtYWlsVmVyaWZpZWQiOnRydWUsImlzTW9iaWxlVmVyaWZpZWQiOnRydWUsImxhc3ROYW1lIjoiIiwiZW1haWwiOiJtZWVuYWtzaGlwcmFrYXNoN0BnbWFpbC5jb20iLCJpc0N1c3RvbWVyRWxpZ2libGVGb3JGcmVlVHJpYWwiOmZhbHNlLCJjb250YWN0SUQiOiI2Mjc3NTQwMCIsImlhdCI6MTY2Mzc1NzU4NiwiZXhwIjoxNjk1MjkzNTg2fQ.F19SRpFtICLnjQ_1n5x-PUsqVTstPVzwMsUQHLruuVI"})
    # _addon.setSetting("isSubscribed", 'true')
else:
    login()


def get_laurl(thdr, tid):
    laurl = []
    la_hdr = thdr

    url = "https://apiv2.sonyliv.com/AGL/1.4/R/ENG/WEB/IN/CONTENT/GETLAURL"

    body = {
        "actionType": "play",
        "assetId": tid,
        "browser": "Chrome",
        "deviceId": la_hdr.get("Device_id"),
        "os": "Chrome",
        "platform": "web",
    }

    body = dumps(body)

    data = requests.post(url, headers=la_hdr, data=body).json()

    laurl.append(
        (
            data["resultObj"].get("laURL"),
            data["resultObj"].get("signature"),
            data["resultObj"].get("token"),
            data["resultObj"].get("drm"),
        )
    )
    return laurl


def go_page(sid, total):
    load_page = window.getProperty("LoadPage")

    if load_page == "True":
        page = xbmcgui.Dialog().numeric(0, "Episodes Page")
        if page:
            page = int(page)
            pages = int(total) / 10
            pages = pages + 1 if int(total) % 10 > 0 else pages
            page = pages - 1 if page > pages else page - 1
            list_episodes(sid, "page", page, total)
            window.setProperty("CurPage", str(page))
    else:
        page = int(window.getProperty("CurPage"))
        window.setProperty("LoadPage", "True")
        list_episodes(sid, "page", page, total)
    return


def get_top():
    """
    Get the list of countries.
    :return: list 532
    """
    MAINLIST = [
        ("TV Shows", "7738", 48),
        ("Movies", "7745", 30),
        ("Sports", "7750", 40),
        ("Live TV", "7878", 9),
        ("Premium", "35223", 19),
        ("Search", "1", 1),
        ("Clear Cache", "2", 2),
    ]
    return MAINLIST


def get_channels(topid, pages):
    """
    Get the list of channels.
    :return: list
    """
    channels = []

    url = "https://apiv2.sonyliv.com/AGL/2.6/R/ENG/WEB/IN/{}/PAGE/{}?kids_safe=true&from=02&to={}".format(
        state, topid, pages
    )
    jd = requests.get(url, headers=headers).json()
    # 
    cnav = jd["resultObj"]["containers"]

    for cn in cnav:
        if cn["metadata"].get("label"):
            title = cn["metadata"].get("label")

            if cn.get('assets'):
                if cn["assets"].get("total"):    # cn["metadata"].get("items_count")
                    cid = cn["metadata"].get("id")
                    """
                    if cn.get('assets'):
                        stype= cn['assets']['containers'][0]['metadata'].get('contentSubtype')  if cn['assets']['containers'] else ''
                    else:
                        stype=''
                    """
                    stype = (
                        jd["resultObj"]["metadata"].get("page_id")
                        if jd.get("resultObj")
                        else ""
                    )
                    uri = cn["actions"][0].get("uri")
                    total = cn["assets"].get("total") if cn.get("assets") else 100
                    channels.append((title, cid, stype, uri, total))
    return channels


def get_shows(cid):
    """
    Get the list of shows.
    :return: list
    """
    show = []
    url = 'https://apiv2.sonyliv.com/AGL/2.6/R/ENG/WEB/IN/{}/PAGE/{}?kids_safe=false'.format(
        state, cid)

    jd = requests.get(url, headers=headers).json()

    if jd["resultObj"]["containers"][0].get("retrieveItems"):
        uri = jd["resultObj"]["containers"][0]["retrieveItems"].get("uri")

        showcount = jd["resultObj"]["containers"][0]["assets"].get("total") if jd["resultObj"]["containers"][0].get("assets") else 9
        get_showlist(uri, 0, showcount)
        show.append((uri, showcount))
    return show


def get_showlist(mainuri, stcount, endcount):
    """
    Get the list of shows.
    :return: list
    """
    shows = []
    fpage = int(stcount) * 10
    lpage = fpage + 9
    if lpage > int(endcount):
        lpage = int(endcount)

    url = 'https://apiv2.sonyliv.com/AGL/2.6/R/ENG/WEB/IN/{}/{}&kids_safe=false&from={}&to={}'.format(
        state, mainuri, fpage, lpage)
    jd = requests.get(url, headers=headers).json()
    items = jd["resultObj"]["containers"]

    for item in items:
        title = (
            item["metadata"].get("episodeTitle")
            if item["metadata"].get("episodeTitle")
            else item["metadata"].get("title")
        )
        labels = {
            "title": title,
            "genre": item["metadata"].get("genres"),
            "plot": item["metadata"].get("longDescription"),
            "mediatype": "tvshow",
        }
        uri = item["actions"][0].get("uri")
        if item["metadata"].get("emfAttributes"):
            fanart = item["metadata"]["emfAttributes"].get(
                "masthead_background")
            if not fanart:
                fanart = item["metadata"]["emfAttributes"].get(
                    "masthead_background_mobile"
                )

            icon = item["metadata"]["emfAttributes"].get("masthead_foreground")
            poster = item["metadata"]["emfAttributes"].get("portrait_thumb")
            thumb = item["metadata"]["emfAttributes"].get("masthead_logo")

            images = {"poster": poster, "icon": icon, "thumb": thumb, "fanart": fanart}
        else:
            images = {"poster": _icon, "icon": _icon, "thumb": _icon, "fanart": _fanart}

        try:
            labels["aired"] = datetime.fromtimestamp(
                item["metadata"].get("contractStartDate") / 1000.0
            ).strftime("%Y-%m-%d")
        except:
            pass

        sid = item["id"]
        stype = item["metadata"].get("objectSubtype")
        shows.append((title, images, sid, labels, stype, uri))

    if int(endcount) > lpage:
        stcount = int(stcount) + 1
        pages = math.ceil(int(endcount) / 10.0)
        title = "Next Page... (Page %s of %s)" % (stcount, pages)
        labels = {}
        images = {"poster": _icon, "icon": _icon,
                  "thumb": _icon, "fanart": _fanart}
        shows.append((title, images, stcount, endcount, "Next", mainuri))
        """
        etitle = "Go Page..."
        labels = {}
        icon = {"poster": _icon, "icon": _icon,
                "thumb": _icon, "fanart": _fanart}
        episodes.append((etitle, images, page, extid, labels, total))
        """
    return shows


"""
def get_showsold(cid):

    shows = []

    url = "https://apiv2.sonyliv.com/AGL/1.6/A/ENG/WEB/IN/PAGE/%s" % (cid)
    # url='https://apiv2.sonyliv.com/AGL/2.6/R/ENG/WEB/IN/MH/PAGE/%s?kids_safe=false'%(cid)

    jd = requests.get(url, headers=headers).json()

    items = jd["resultObj"]["containers"][0]["assets"]["containers"]
    for item in items:
        title = (
            item["metadata"].get("episodeTitle")
            if item["metadata"].get("episodeTitle")
            else item["metadata"].get("title")
        )
        labels = {
            "title": title,
            "genre": item["metadata"].get("genres"),
            "plot": item["metadata"].get("longDescription"),
            "mediatype": "tvshow",
        }
        uri = item["actions"][0].get("uri")
        if item["metadata"].get("emfAttributes"):
            fanart = item["metadata"]["emfAttributes"].get(
                "masthead_background")
            if not fanart:
                fanart = item["metadata"]["emfAttributes"].get(
                    "masthead_background_mobile"
                )

            icon = item["metadata"]["emfAttributes"].get("masthead_foreground")
            poster = item["metadata"]["emfAttributes"].get("portrait_thumb")
            thumb = item["metadata"]["emfAttributes"].get("masthead_logo")

            images = {"poster": poster, "icon": icon,
                      "thumb": thumb, "fanart": fanart}
        else:
            images = {"poster": _icon, "icon": _icon,
                      "thumb": _icon, "fanart": _fanart}

        try:
            labels["aired"] = datetime.fromtimestamp(
                item["metadata"].get("contractStartDate") / 1000.0
            ).strftime("%Y-%m-%d")
        except:
            pass

        sid = item["id"]
        stype = item["metadata"].get("objectSubtype")
        shows.append((title, images, sid, labels, stype, uri))
    return shows
"""


def get_season(sid):
    """
    Get the list of episodes.
    :return: list
    """
    season = []
    url = "https://apiv2.sonyliv.com/AGL/2.6/R/ENG/WEB/IN/{}/DETAIL/{}?kids_safe=false&from=0&to=9".format(
        state, sid
    )
    jd = requests.get(url, headers=headers).json()

    if jd["resultCode"] == "OK":
        items = jd["resultObj"]["containers"][0]["containers"]

        for item in items:
            subtype = item["metadata"].get("contentSubtype")
            if item.get("episodeCount"):
                tcount = item.get("episodeCount")
            else:
                tcount = 100
            if subtype == "EPISODE":
                stitle = "%s Episode %s" % (
                    item["metadata"].get("title"),
                    item["metadata"].get("episodeNumber"),
                )
                labels = {
                    "title": stitle,
                    "duration": item["metadata"].get("duration"),
                    "episode": item["metadata"].get("episodeNumber"),
                    "year": item["metadata"].get("year"),
                    "tvshowtitle": stitle,
                    "mediatype": "episode",
                }
            else:
                stitle = (
                    item["metadata"].get("episodeTitle")
                    if item["metadata"].get("episodeTitle")
                    else item["metadata"].get("title")
                )
                labels = {"title": stitle, "mediatype": "season"}

            fanart = item["metadata"]["emfAttributes"].get(
                "tv_background_image")
            poster = item["metadata"]["emfAttributes"].get("poster")
            icon = item["metadata"]["emfAttributes"].get("landscape_thumb")
            thumb = item["metadata"]["emfAttributes"].get("thumbnail")

            icon = {"poster": poster, "icon": icon,
                    "thumb": thumb, "fanart": fanart}

            sid = item["id"]
            labels["genre"] = item["metadata"].get("genres")
            labels["plot"] = item["metadata"].get("longDescription")
            labels["aired"] = (
                datetime.fromtimestamp(
                    item["metadata"].get("originalAirDate") / 1000.0
                ).strftime("%Y-%m-%d")
                if item["metadata"].get("originalAirDate")
                else None
            )
            season.append((stitle, icon, sid, subtype, labels, tcount))

    return season


def get_episodes(sid, title, page, total):
    """
    Get the list of episodes.
    :return: list
    """
    episodes = []
    page = int(page)
    fpage = int(page) * 10
    tpage = fpage + 9

    url = (
        "https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/CONTENT/DETAIL/BUNDLE/%s?from=%s&to=%s"
        % (sid, fpage, tpage)
    )
    jd = requests.get(url, headers=headers).json()
    items = jd["resultObj"]["containers"][0]["containers"]
    for item in items:
        etitle = "{} - Episodes {}".format(
            six.ensure_str(
                item["metadata"].get("episodeTitle"), encoding="utf-8", errors="strict"
            ),
            item["metadata"].get("episodeNumber"),
        )
        eid = item.get("id")
        extid = item["metadata"].get("externalId")
        plot = item["metadata"].get("longDescription")
        if item["metadata"]["emfAttributes"].get("cast_and_crew") is not None:
            plot = (
                plot + "\n\n" + item["metadata"]["emfAttributes"].get("cast_and_crew")
            )

        labels = {
            "title": etitle,
            "genre": item["metadata"].get("genres"),
            # 'cast':item['metadata'].get('actors'),
            "plot": plot,
            "duration": item["metadata"].get("duration"),
            "episode": item["metadata"].get("episodeNumber"),
            "tvshowtitle": etitle,
            "year": item["metadata"].get("year"),
            "aired": datetime.fromtimestamp(
                item["metadata"].get("originalAirDate") / 1000.0
            ).strftime("%Y-%m-%d")
            if item["metadata"].get("originalAirDate")
            else None,
            "mediatype": "episode",
        }
        fanart = item["metadata"]["emfAttributes"].get("tv_background_image")
        poster = item["metadata"]["emfAttributes"].get("poster")
        icon = item["metadata"]["emfAttributes"].get("landscape_thumb")
        thumb = item["metadata"]["emfAttributes"].get("thumbnail")

        images = {"poster": poster, "icon": icon,
                  "thumb": thumb, "fanart": fanart}

        episodes.append((etitle, images, eid, extid, labels, total))
    total = (
        items[0].get("episodeCount")
        if items[0].get("episodeCount") is not None
        else total
    )
    page += 1
    BalCount = int(total) - page * 10
    if BalCount > 0:
        pages = math.ceil(int(total) / 10.0)
        # pages=pages+1 if int(total)%10 >0 else pages
        etitle = "Next Page... (Page %s of %s)" % (page, pages)
        labels = {}
        images = {"poster": _icon, "icon": _icon,
                  "thumb": _icon, "fanart": _fanart}
        episodes.append((etitle, images, page, extid, labels, total))
        etitle = "Go Page..."
        labels = {}
        icon = {"poster": _icon, "icon": _icon,
                "thumb": _icon, "fanart": _fanart}
        episodes.append((etitle, images, page, extid, labels, total))
    return episodes


def get_video(gid, page, uri, total):
    """
    Get the list of video.
    :return: list
    """
    video = []
    page = int(page)
    fpage = int(page) * 10
    tpage = (int(page) + 1) * 10 - 1

    if uri.find("SEARCH") == -1:
        url = "https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN/PAGE/%s?from=0&to=9" % (
            gid
        )
        NoNext = True
        jd = requests.get(url, headers=headers).json()
        items = jd["resultObj"]["containers"][0]["assets"]["containers"]
    else:
        url = "https://apiv2.sonyliv.com/AGL/1.4/A/ENG/WEB/IN%s&from=%s&to=%s" % (
            uri,
            fpage,
            tpage,
        )
        NoNext = False
        jd = requests.get(url, headers=headers).json()
        items = jd["resultObj"]["containers"]

    for item in items:
        mtitle = six.ensure_str(
            item["metadata"].get("title"), encoding="utf-8", errors="strict"
        )
        if item["metadata"].get("episodeTitle"):
            if mtitle.strip() != item["metadata"].get("episodeTitle").strip():
                mtitle = "{} ({})".format(
                    six.ensure_str(
                        item["metadata"].get("episodeTitle"),
                        encoding="utf-8",
                        errors="strict",
                    ),
                    mtitle,
                )
        mid = item.get("id")

        mextid = item["metadata"].get("externalId")
        subtype = item["metadata"].get("contentSubtype")
        plot = item["metadata"].get("longDescription")

        if item["metadata"].get("emfAttributes"):
            if item["metadata"]["emfAttributes"].get("cast_and_crew"):
                plot = (
                    plot + "\n\n" + item["metadata"]["emfAttributes"].get("cast_and_crew")
                )
            if item["metadata"]["emfAttributes"].get("is_preview_enabled") is False:
                subtype = "EPISODE"
            fanart = item["metadata"]["emfAttributes"].get(
                "tv_background_image")
            poster = item["metadata"]["emfAttributes"].get("portrait_thumb")
            if not poster:
                poster = item["metadata"]["emfAttributes"].get("thumbnail")
            icon = item["metadata"]["emfAttributes"].get("landscape_thumb")
            thumb = item["metadata"]["emfAttributes"].get("thumbnail")

            images = {"poster": poster, "icon": icon,
                      "thumb": thumb, "fanart": fanart}
        else:
            images = {"poster": _icon, "icon": _icon,
                      "thumb": _icon, "fanart": _fanart}

        labels = {
            "title": mtitle,
            "genre": item["metadata"].get("genres"),
            # 'cast':item['metadata']['emfAttributes'].get('cast_and_crew'),
            "plot": plot,
            "duration": item["metadata"].get("duration"),
            "year": item["metadata"].get("year"),
            "mediatype": "movie",
        }

        try:
            labels["premiered"] = datetime.fromtimestamp(
                item["metadata"].get("originalAirDate") / 1000.0
            ).strftime("%Y-%m-%d")
        except:
            pass

        video.append((mtitle, images, mid, mextid, subtype, labels, total))
    if NoNext is False:
        page += 1
        BalCount = int(total) - page * 10
        if BalCount > 0:
            pages = math.ceil(int(total) / 10.0)
            # pages=pages+1 if int(total)%10 >0 else pages
            mtitle = "Next Page... (Page %s of %s)" % (page, pages)
            labels = {}
            icon = {"poster": _icon, "icon": _icon,
                    "thumb": _icon, "fanart": fanart}
            video.append(
                (mtitle, images, page, mextid, subtype, labels, total))

    return video


def get_search(sid):
    """
    Get the list of shows.
    :return: list
    """
    search = []

    url = (
        "https://apiv2.sonyliv.com/AGL/2.4/A/ENG/WEB/IN/%s/TRAY/SEARCH?query=%s&from=0&to=9&kids_safe=true"
        % (state, sid)
    )

    jd = requests.get(url, headers=headers).json()
    for x in range(2):
        items = jd["resultObj"]["containers"][x]["containers"]
        for item in items:
            title = six.ensure_str(
                item["metadata"].get("title"), encoding="utf-8", errors="strict"
            )
            if item["metadata"].get("episodeTitle"):
                if title.strip() != item["metadata"].get("episodeTitle").strip():
                    title = "{} ({})".format(
                        six.ensure_str(
                            item["metadata"].get("episodeTitle"),
                            encoding="utf-8",
                            errors="strict",
                        ),
                        title,
                    )

            labels = {
                "title": title,
                "genre": item["metadata"].get("genres"),
                "plot": item["metadata"].get("longDescription"),
                "mediatype": "tvshow",
            }

            if item["metadata"].get("emfAttributes"):
                fanart = item["metadata"]["emfAttributes"].get(
                    "masthead_background")
                if not fanart:
                    fanart = item["metadata"]["emfAttributes"].get(
                        "masthead_background_mobile"
                    )

                icon = item["metadata"]["emfAttributes"].get(
                    "masthead_foreground")
                poster = item["metadata"]["emfAttributes"].get(
                    "portrait_thumb")
                thumb = item["metadata"]["emfAttributes"].get("masthead_logo")

                images = {
                    "poster": poster,
                    "icon": icon,
                    "thumb": thumb,
                    "fanart": fanart,
                }
            else:
                images = {
                    "poster": _icon,
                    "icon": _icon,
                    "thumb": _icon,
                    "fanart": _fanart,
                }

            try:
                labels["aired"] = datetime.fromtimestamp(
                    item["metadata"].get("contractStartDate") / 1000.0
                ).strftime("%Y-%m-%d")
            except:
                pass

            sid = item["id"]
            stype = item["metadata"].get("objectSubtype")
            total = item["assets"].get("total") if item.get("assets") else 100
            search.append((title, images, sid, stype, x, total))
    return search


def list_top():
    """
    Create the list of countries in the Kodi interface.
    """
    items = get_top()
    listing = []
    for title, topid, pages in items:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo("video", {"title": title})
        list_item.setProperty("IsPlayable", "false")
        list_item.setArt(
            {"poster": _icon, "icon": _icon, "thumb": _icon, "fanart": _fanart}
        )
        url = "{0}?action=list_second&topid={1}&pages={2}".format(
            _url, topid, pages)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)


def list_channels(topid, pages):
    """
    Create the list of countries in the Kodi interface.
    """

    channels = cache.cacheFunction(get_channels, topid, pages)
    listing = []

    for title, cid, stype, uri, tcount in channels:
        if stype:
            list_item = xbmcgui.ListItem(
                label="[COLOR yellow]%s[/COLOR]" % title)
            list_item.setProperty("IsPlayable", "false")
            list_item.setArt(
                {"poster": _icon, "icon": _icon, "thumb": _icon, "fanart": _fanart}
            )
            list_item.setInfo("video", {"title": title})
            # ['CLIP','BEHIND_THE_SCENES','MOVIE','LIVE_CHANNEL','LIVE_SPORT', 'SPORTS_CLIPS','HIGHLIGHTS']
            if stype in [
                "CLIP",
                "BEHIND_THE_SCENES",
                "movies",
                "channels",
                "LIVE_SPORT",
                "HIGHLIGHTS",
            ]:
                url = "{0}?action=list_video&mgid={1}&url={2}&page=0&total={3}".format(
                    _url, cid, quote(uri), tcount
                )
            else:
                show = get_shows(cid)
                url = "{0}?action=list_show&url={1}&stshow={2}&endshow={3}".format(_url, show[0][0], 0, show[0][1])
            is_folder = True
            listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


"""
def list_shows(cid):
    shows = get_shows(cid)
    listing = []
    for title, icon, sid, labels, stype, uri in shows:
        list_item = xbmcgui.ListItem(label="[COLOR yellow]%s[/COLOR]" % title)
        list_item.setArt(icon)
        list_item.setInfo("video", labels)
        list_item.setProperty("IsPlayable", "false")

        if stype in ["LAUNCHER"]:
            url = "{0}?action=list_video&mgid={1}&url={2}&page=0&total={3}".format(
                _url, sid, quote(uri), 10
            )
            is_folder = True
        elif stype in ["MOVIE", "SPORTS_CLIPS", "EPISODE", "HIGHLIGHTS"]:
            list_item.setProperty("IsPlayable", "true")
            url = "{0}?action=Play&video={1}&ltype={2}".format(
                _url, sid, "Stream")
            is_folder = False
            xbmcplugin.setContent(_handle, "tvshows")
        elif stype in ["Next"]:
            url = "{0}?action=list_show&url={1}&stshow={2}&endshow={3}".format(
                _url, quote(uri), sid, labels)
            is_folder = True
        else:
            url = "{0}?action=list_season&title={1}&sid={2}&page=0".format(
                _url, six.ensure_str(
                    title, encoding="utf-8", errors="strict"), sid
            )
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)
"""


def list_show(url, stshow, endshow):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = cache.cacheFunction(get_showlist, url, stshow, endshow)
    listing = []
    for title, icon, sid, labels, stype, uri in shows:
        list_item = xbmcgui.ListItem(label="[COLOR yellow]%s[/COLOR]" % title)
        list_item.setArt(icon)
        list_item.setInfo("video", labels)
        list_item.setProperty("IsPlayable", "false")

        if stype in ["LAUNCHER"]:
            url = "{0}?action=list_video&mgid={1}&url={2}&page=0&total={3}".format(
                _url, sid, quote(uri), 10
            )
            is_folder = True
        elif stype in ["MOVIE", "SPORTS_CLIPS", "EPISODE", "HIGHLIGHTS"]:
            list_item.setProperty("IsPlayable", "true")
            url = "{0}?action=Play&video={1}&ltype={2}".format(
                _url, sid, "Stream")
            is_folder = False
            xbmcplugin.setContent(_handle, "tvshows")
        elif stype in ["Next"]:
            url = "{0}?action=list_show&url={1}&stshow={2}&endshow={3}".format(
                _url, quote(uri), sid, labels)
            is_folder = True
        else:
            url = "{0}?action=list_season&title={1}&sid={2}&page=0".format(
                _url, six.ensure_str(
                    title, encoding="utf-8", errors="strict"), sid
            )
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)


def list_season(seasonid):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = cache.cacheFunction(get_season, seasonid)
    listing = []
    for title, icon, sid, stype, labels, tcount in shows:
        list_item = xbmcgui.ListItem(label="[COLOR yellow]%s[/COLOR]" % title)
        list_item.setArt(icon)
        list_item.setInfo("video", labels)

        if stype in ["EPISODE", "SPORTS_CLIPS"]:
            list_item.setProperty("IsPlayable", "true")
            url = "{0}?action=Play&video={1}&ltype={2}".format(
                _url, sid, "Stream")
            is_folder = False
            xbmcplugin.setContent(_handle, "tvshows")
        else:
            list_item.setProperty("IsPlayable", "false")
            url = "{0}?action=list_episodes&sid={1}&title={2}&page=0&total={3}".format(
                _url, sid, quote(title), tcount
            )
            is_folder = True
        listing.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def list_episodes(sid, title, page, total):
    """
    Create the list of episodes in the Kodi interface.

    """
    window.setProperty("LoadPage", "True")
    episodes = cache.cacheFunction(get_episodes, sid, title, page, total)
    listing = []

    for etitle, icon, eid, extid, labels, tcount in episodes:
        list_item = xbmcgui.ListItem(label=etitle)
        list_item.setArt(icon)
        list_item.setInfo("video", labels)
        if "Next Page" in etitle:
            list_item.setProperty("IsPlayable", "false")
            url = (
                "{0}?action=list_episodes&sid={1}&title={2}&page={3}&total={4}".format(
                    _url, sid, "Next", eid, tcount
                )
            )
            is_folder = True
        elif "Go Page" in etitle:
            list_item.setProperty("IsPlayable", "false")
            # url = '{0}?action=list_episodes&sid={1}&title={2}&page={3}&total={4}'.format(_url, sid, 'GoPage', eid,tcount)
            url = "{0}?action=gopage&sid={1}&total={2}".format(
                _url, sid, tcount)
            is_folder = True
        else:
            list_item.setProperty("IsPlayable", "true")
            url = "{0}?action=Play&video={1}&ltype={2}".format(
                _url, eid, "Stream")
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, "episodes")
    xbmcplugin.endOfDirectory(_handle)


def list_video(gid, uri, page, total):
    """
    Create the list of episodes in the Kodi interface.
    """

    video = cache.cacheFunction(get_video, gid, page, uri, total)
    listing = []

    for title, icon, mid, extid, stype, labels, tcount in video:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo("video", labels)

        if "Next Page" in title:
            list_item.setProperty("IsPlayable", "false")
            url = "{0}?action=list_video&mgid={1}&url={2}&page={3}&total={4}".format(
                _url, gid, quote(uri), mid, tcount
            )
            is_folder = True
        else:
            list_item.setProperty("IsPlayable", "true")
            list_item.addStreamInfo("video", {"codec": "h264"})
            # list_item.addStreamInfo('audio', { 'codec': 'mp4', 'channels': 2 })
            if stype in ("LIVE_CHANNEL", "LIVE_SPORT"):
                url = "{0}?action=Play&video={1}&ltype={2}".format(
                    _url, mid, "Live")
            else:
                url = "{0}?action=Play&video={1}&ltype={2}".format(
                    _url, mid, "Stream")

            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, "movies")
    xbmcplugin.endOfDirectory(_handle)


def get_user_input():
    kb = xbmc.Keyboard(
        "", "Search for Movies/TV Shows/Trailers/Videos in all languages"
    )
    kb.doModal()  # Onscreen keyboard appears
    if not kb.isConfirmed():
        return

    # User input
    return kb.getText()


def list_search(sid):
    """
    Create the list of channels in the Kodi interface.
    """

    query = get_user_input()
    if not query:
        return []

    # shows = cache.cacheFunction(get_search,query)
    shows = get_search(query)
    listing = []

    for title, images, sid, stype, xidx, tcount in shows:
        list_item = xbmcgui.ListItem(label="[COLOR yellow]%s[/COLOR]" % title)
        list_item.setArt(images)
        # list_item.setInfo('video', labels)
        list_item.setProperty("IsPlayable", "false")
        if xidx == 0:
            url = "{0}?action=list_season&title={1}&sid={2}&page=0".format(
                _url, quote(title), sid
            )
            is_folder = True
        else:
            url = "{0}?action=Play&video={1}&ltype={2}".format(
                _url, sid, "Stream")
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, "tvshows")
    xbmcplugin.endOfDirectory(_handle)


def play_video(vid, ltype):
    """
    Play a video by the provided video id.

    :param vid: str
    """

    phdr = headers

    phdr.update({"x-playback-session-id": headers["Device_id"]})
    contactID = GETPROFILE()
    if ltype == "Live":
        #url = (
        #    "https://apiv2.sonyliv.com/AGL/1.5/R/ENG/WEB/IN/CONTENT/VIDEOURL/VOD/%s/freepreview"
        #    % vid
        url = "https://apiv2.sonyliv.com/AGL/3.2/R/ENG/WEB/IN/ALL/CONTENT/VIDEOURL/VOD/{}/freepreview?contactId={}".format(vid, contactID)

        jd = requests.get(url, headers=phdr).json()

        if jd.get("resultCode") == "OK":
            stream_url = jd["resultObj"].get("videoURL")
            if not stream_url:
                url = "https://pubads.g.doubleclick.net/ssai/event/%s/streams" % jd["resultObj"].get("dai_asset_key")
                body = {}
                body = dumps(body)
                data = requests.post(url, headers=phdr, data=body).json()

                if data:
                    if data.get("stream_manifest"):
                        stream_url = data.get("stream_manifest")
                    else:
                        stream_url = "{}&originpath=/linear/hls/pb/event/{}/stream/{}/master.m3u8".format(
                            jd["resultObj"].get("videoURL").lstrip(),
                            jd["resultObj"].get("dai_asset_key"),
                            data.get("stream_id")
                        )
    else:

        if _settings("isSubscribed").lower() == 'false':
            url = (
                "https://apiv2.sonyliv.com/AGL/3.0/R/ENG/WEB/IN/{}/CONTENT/VIDEOURL/VOD/{}?contactId={}".format(state, vid, contactID))
        else:
            url = (
                "https://apiv2.sonyliv.com/AGL/3.0/SR/ENG/WEB/IN/{}/CONTENT/VIDEOURL/VOD/{}?contactId={}".format(state, vid, contactID))
        r = requests.get(url, headers=phdr)
        jd = r.json()
        if r.status_code > 400:
            xbmc.executebuiltin(
                "Notification(%s, %s, %d, %s)"
                % (_addonname, jd.get("message"), 3500, _icon)
            )
            return
        stream_url = jd["resultObj"].get("videoURL")

    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setPath(stream_url)

    hdr = {
        "x-playback-session-id": headers["Device_id"], "user-agent": USER_AGENT}

    play_item.setProperty(
        "inputstream.adaptive.license_type", "com.widevine.alpha")

    if six.PY3:
        play_item.setProperty("inputstream", "inputstream.adaptive")
    else:
        play_item.setProperty("inputstreamaddon", "inputstream.adaptive")

    if stream_url.find("mpd") != -1:
        play_item.setProperty("inputstream.adaptive.manifest_type", "mpd")
        play_item.setMimeType("application/dash+xml")
    elif stream_url.find("ism") != -1:
        play_item.setProperty("inputstream.adaptive.manifest_type", "ism")
        play_item.setMimeType("application/vnd.ms-sstr+xml")
        play_item.setProperty(
            "inputstream.adaptive.license_type", "com.microsoft.playready"
        )
    else:
        play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
        play_item.setMimeType("application/vnd.apple.mpegurl")

    play_item.setContentLookup(False)

    if jd["resultObj"].get("isEncrypted"):
        GETLAURL = get_laurl(phdr, vid)
        lic_url = GETLAURL[0][0]
        license_key = "%s|Content-Type=%s|R{SSM}|" % (lic_url, urlencode(hdr))
    else:
        license_key = "|Content-Type=&%s|R{SSM}|" % (
            urlencode(hdr))

    play_item.setProperty("inputstream.adaptive.license_key", license_key)
    play_item.setProperty(
        "inputstream.adaptive.stream_headers", urlencode(hdr)
    )
    play_item.setProperty("inputstream.adaptive.manifest_headers", urlencode(hdr))
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin

    if params:
        if params["action"] == "list_second":
            if params["topid"] == "1":
                list_search(params["topid"])
            elif params["topid"] == "2":
                clear_cache()
            else:
                list_channels(params["topid"], params["pages"])
        elif params["action"] == "list_show":
            list_show(params["url"], params["stshow"], params["endshow"],)
        elif params["action"] == "list_season":
            list_season(params["sid"])
        elif params["action"] == "list_video":
            list_video(params["mgid"], params["url"],
                       params["page"], params["total"])
        elif params["action"] == "list_episodes":
            list_episodes(
                params["sid"], params["title"], params["page"], params["total"]
            )
        elif params["action"] == "Play":
            window.setProperty("LoadPage", "False")
            play_video(params["video"], params["ltype"])
        elif params["action"] == "gopage":
            go_page(params["sid"], params["total"])

    else:
        list_top()


if __name__ == "__main__":
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring

    router(sys.argv[2][1:])

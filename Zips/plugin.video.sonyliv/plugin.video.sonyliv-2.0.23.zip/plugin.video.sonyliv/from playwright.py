from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()

    page.goto("https://www.sonyliv.com")
    page.wait_for_timeout(10000)

    cookies = page.context.cookies()

abck = None
session_id = None

for cookie in cookies:
    if cookie["name"] == "_abck":
        abck = cookie["value"]
    elif cookie["name"] == "sessionId":
        session_id = cookie["value"]

cookie_header = ""

if abck:
    cookie_header += f"_abck={abck}"

if session_id:
    if cookie_header:
        cookie_header += ";"
    cookie_header += f"sessionId={session_id}"

print(cookie_header)


import requests

session = requests.Session()
response = session.get("https://www.sonyliv.com")

print(session.cookies)